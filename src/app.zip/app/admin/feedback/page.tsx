'use client';

import Nav from "../nav/nav"; 
import "../../css/feedbackAdmin.css";

export default function FeedbackAdminPage(){
    return(
        <>
          <Nav/> 
          <div id="content">
            <main>
                <div className="head-title">
                <div className="left">
                    <h1>Quản lý bình luận</h1>
                </div>
                </div>
  
                </main>
            </div>
        </>
      
        
    )
}